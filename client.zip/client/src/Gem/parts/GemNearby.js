import React from "react";

const GemNearby = () => {
  return <div className="GemNearby_box">This is nearby Gem</div>;
};
export default GemNearby;
