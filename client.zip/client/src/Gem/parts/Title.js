import React from "react";

function Title(props) {
  return (
    <div className="gemTitle">
      <h1>
          {props.Title}
      </h1>
    </div>
  );
}

export default Title;
